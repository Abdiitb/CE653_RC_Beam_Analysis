% CE653 - RC beam reliability, current agreed 6 m design.
% Standalone SCRIPT: press Run or type its filename (without .m).
% MATLAB R2016b or later; NO Statistics or Optimization Toolbox required.
% Local functions appear at the end. Run the complete script, not a selection.
% Each file contains its own identical input/model functions for portability.
% Edit beam_parameters() below to change inputs; keep all four copies aligned.
% Assumption: independent basic variables, common diameter for all 3 bars.
% No load factors 1.5 or material factor 0.87 in the probabilistic g function.
clear; clc;
p=beam_parameters();
show_parameters(p);

%% Hasofer-Lind / FORM in independent standard-normal space
% Exact marginal transformation X_i = F_i^{-1}(Phi(U_i)).
% Solve min ||u|| subject to h(u)=g(T(u))=0 using damped HLRF.
% A merit-function line search prevents undamped HLRF oscillation.
% Multiple starts check for competing local design points (not a global proof).
gScale=max(abs(beam_limit_state(p.mu,p)),1);
h=@(u) beam_limit_state(from_standard_normal(u,p),p)/gScale;
n=numel(p.mu);
starts=zeros(5,n); starts(2,10)=3; starts(3,1)=-3;
starts(4,11)=-3; starts(5,2)=-3;
options.maxIterations=300;
options.tolH=1e-8;
options.tolKKT=1e-6;
options.fdStep=1e-4;
solutions=cell(size(starts,1),1); distances=inf(size(starts,1),1);
fprintf('\nFORM MULTI-START CHECK\n');
for k=1:size(starts,1)
    sol=hlrf_solve(h,starts(k,:),options);
    solutions{k}=sol;
    if sol.converged, distances(k)=norm(sol.u); end
    fprintf('Start %d: converged=%d, iterations=%d, ||u||=%.8f, |h|=%.3g\n', ...
        k,sol.converged,sol.iterations,norm(sol.u),abs(h(sol.u)));
end
[distance,best]=min(distances);
if ~isfinite(distance)
    error('FORM did not converge. Inspect solutions and adjust the solver; no beta reported.');
end
sol=solutions{best}; uStar=sol.u; xStar=from_standard_normal(uStar,p);
[gStar,RStar,SStar,dStar]=beam_limit_state(xStar,p);
grad=central_gradient(h,uStar,options.fdStep*ones(1,n));
gradFine=central_gradient(h,uStar,0.5*options.fdStep*ones(1,n));
gradCheck=norm(grad-gradFine)/max(norm(gradFine),eps);
assert(gradCheck<1e-4,'FORM gradient did not stabilize.');
alpha=gradFine/norm(gradFine); % points toward increasing safety
originSign=sign(h(zeros(1,n)));
if originSign==0, originSign=1; end
beta=originSign*distance;
Pf=0.5*erfc(beta/sqrt(2));
stationarity=norm(uStar-dot(uStar,alpha)*alpha);
assert(abs(h(uStar))<options.tolH && stationarity<1e-5, ...
    'Final limit-state or stationarity residual is too large.');
results=struct('method','Hasofer-Lind FORM','parameters',p,'beta',beta,'Pf_FORM',Pf, ...
    'u_star',uStar,'x_star',xStar,'g_star',gStar,'R_star',RStar,'S_star',SStar, ...
    'alpha_safe_direction',alpha,'importance_alpha_squared',alpha.^2, ...
    'stationarity_residual',stationarity,'gradient_check_relative',gradCheck, ...
    'history',sol.history,'all_solutions',{solutions});
fprintf('\nHASOFER-LIND / FORM RESULTS\n');
fprintf('beta_FORM = %.8f; Pf_FORM = %.8g\n',beta,Pf);
fprintf('g(x*) = %.6g kN m; KKT residual = %.3g\n',gStar,stationarity);
fprintf('R(x*) = %.6f; S(x*) = %.6f kN m\n',RStar,SStar);
fprintf('\n%-11s %12s %12s %12s %12s\n','Variable','x*','u*','alpha','alpha^2');
for j=1:n
    fprintf('%-11s %12.6g %12.6g %12.6g %12.6g\n',p.names{j},xStar(j),uStar(j),alpha(j),alpha(j)^2);
end
fprintf('\nalpha points toward safety; for this safe origin u* ~= -beta*alpha.\n');
fprintf('History columns: iteration, ||u||, h(u), HLRF residual.\n');
disp(sol.history);
show_diagnostic(sum(dStar.nonYield),sum(dStar.invalid),sum(dStar.negativeQ),1);
fprintf('FORM is a tangent-plane probability approximation, not exact integration.\n');
fprintf('The output structure is named results. No files are written.\n');

%% Local functions

function p = beam_parameters()
% Variable order is identical in all four standalone scripts.
% All 11 basic variables are assumed INDEPENDENT. Derived variables are not.
% References and transfer assumptions are documented in README.md.
p.names = {'C','F','b','D','c','phi_l','phi_st','gamma_RC','G','Q','theta_R'};
p.units = {'MPa','MPa','mm','mm','mm','mm','mm','kN/m^3','kN/m','kN/m','-'};
p.L = 6;                         % fixed effective span, m
p.nBars = 3;                     % three bars sharing one random diameter
p.Es = 200000; p.epscu = 0.0035; % only for yield-assumption diagnostic
% M25: 25 MPa is assumed to be the 5th percentile; COV = 0.15.
p.logSD_C = sqrt(log(1+0.15^2));
p.logMean_C = log(25)+1.6448536269514722*p.logSD_C;
muC = exp(p.logMean_C+0.5*p.logSD_C^2);
muQ = 10/(1+0.35*0.25);          % Correia et al. nominal-to-mean relation
p.mu = [muC,560,250.75,451.35,30,20,8,25,5.25,muQ,1.01];
p.sd = [0.15*muC,30,5.50,6.70,3,0.20,0.08,1.25,0.525,0.25*muQ,0.0465];
p.type = {'Lognormal','Normal','Normal','Normal','Normal','Normal', ...
          'Normal','Normal','Normal','Gumbel-max','Normal'};
p.gumbelScale = p.sd(10)*sqrt(6)/pi;
p.gumbelLocation = p.mu(10)-0.5772156649015329*p.gumbelScale;
end

function [g,R,S,diag] = beam_limit_state(X,p)
% Rows = samples; columns use p.names. Strengths MPa, lengths mm except L(m).
% EXACT agreed Ranganathan flexural model, WITHOUT partial safety factors.
C=X(:,1); F=X(:,2); b=X(:,3); D=X(:,4); c=X(:,5);
phiL=X(:,6); phiSt=X(:,7); gamma=X(:,8); G=X(:,9); Q=X(:,10); B=X(:,11);
As=p.nBars*pi*phiL.^2/4;
d=D-c-phiSt-phiL/2;
wSelf=gamma.*b.*D*1e-6;  % effective RC weight already includes steel
R=1e-6*B.*F.*As.*(d-0.77*F.*As./(b.*C));
S=(G+Q+wSelf)*p.L^2/8;
g=R-S;                 % kN m; failure g <= 0
if nargout>3
    % Do NOT reject, truncate or alter samples: doing so changes the model.
    diag.invalid = any(~isfinite(X),2) | any(X(:,[1:9,11])<=0,2) | d<=0;
    diag.negativeQ = Q<0; % tiny formal negative tail of Gumbel distribution
    % Diagnostic only: steel-yield resistance requires strain compatibility.
    xu=F.*As./(0.546*C.*b);
    diag.yieldLimit = p.epscu./(p.epscu+F/p.Es);
    diag.xuOverD = xu./d;
    diag.nonYield = diag.xuOverD > diag.yieldLimit;
    diag.As=As; diag.d=d; diag.wSelf=wSelf;
end
end

function X = from_uniform(P,p)
% Independent inverse-CDF transform, including Gumbel for MAXIMA.
P=min(max(P,realmin),1-eps);
Z=-sqrt(2)*erfcinv(2*P);
X=bsxfun(@plus,p.mu,bsxfun(@times,Z,p.sd));
X(:,1)=exp(p.logMean_C+p.logSD_C*Z(:,1));
X(:,10)=p.gumbelLocation-p.gumbelScale*log(-log(P(:,10)));
end

function X = from_standard_normal(U,p)
X=bsxfun(@plus,p.mu,bsxfun(@times,U,p.sd));
X(:,1)=exp(p.logMean_C+p.logSD_C*U(:,1));
% Phi(U), numerically protected at machine precision only.
P=min(max(0.5*erfc(-U(:,10)/sqrt(2)),realmin),1-eps);
X(:,10)=p.gumbelLocation-p.gumbelScale*log(-log(P));
end

function grad = central_gradient(fun,x,step)
% Returns a row gradient. Check two step sizes in the deterministic methods.
grad=zeros(size(x));
for j=1:numel(x)
    xp=x; xm=x; xp(j)=xp(j)+step(j); xm(j)=xm(j)-step(j);
    grad(j)=(fun(xp)-fun(xm))/(2*step(j));
end
end

function b = beta_from_pf(pf)
% beta = -Phi^{-1}(Pf); returns +Inf for Pf=0 and -Inf for Pf=1.
b=sqrt(2)*erfcinv(2*pf);
end

function show_parameters(p)
fprintf('\nIndependent basic variables (arithmetic mean and SD):\n');
fprintf('%-11s %-13s %12s %12s %-8s\n','Variable','Distribution','Mean','SD','Unit');
for j=1:numel(p.mu)
    fprintf('%-11s %-13s %12.6g %12.6g %-8s\n',p.names{j},p.type{j},p.mu(j),p.sd(j),p.units{j});
end
fprintf('Span = %.3f m; number of tension bars = %d.\n',p.L,p.nBars);
fprintf('Model: Ranganathan yielded-steel flexure, independent inputs.\n');
end

function show_diagnostic(nonYield,invalid,negativeQ,N)
if invalid>0
    warning('Beam:InvalidSamples', ...
      '%d / %d samples have invalid geometry or nonpositive physical inputs. Results include them; review model.',invalid,N);
end
if negativeQ>0
    warning('Beam:NegativeLiveLoad','%d negative Gumbel live-load samples retained.',negativeQ);
end
if nonYield>0
    warning('Beam:YieldAssumption', ...
      ['%d / %d samples (%.5g%%) exceed the steel-yield strain limit. ', ...
       'The agreed equation was retained; results refer to this equation, not a multi-mode capacity model.'], ...
      nonYield,N,100*nonYield/N);
end
end

function sol=hlrf_solve(h,u,opt)
penalty=1; hist=zeros(opt.maxIterations+1,4); converged=false;
reason='maximum iterations';
for it=0:opt.maxIterations
    hv=h(u);
    grad=central_gradient(h,u,opt.fdStep*ones(size(u)));
    norm2=dot(grad,grad);
    if ~isfinite(hv) || ~isfinite(norm2) || norm2<=eps^2
        reason='nonfinite function or zero gradient'; break;
    end
    projected=((dot(grad,u)-hv)/norm2)*grad;
    direction=projected-u;
    hist(it+1,:)=[it,norm(u),hv,norm(direction)];
    if abs(hv)<opt.tolH && norm(direction)<opt.tolKKT
        converged=true; reason='converged'; break;
    end
    if it==opt.maxIterations, break; end
    penalty=max(penalty,2*norm(u)/sqrt(norm2)+1);
    slope=dot(u,direction)-penalty*abs(hv);
    if slope>=0 && abs(hv)>1e-14
        penalty=max(penalty,(dot(u,direction)+norm(direction)^2)/abs(hv)+1);
        slope=dot(u,direction)-penalty*abs(hv);
    end
    merit=0.5*dot(u,u)+penalty*abs(hv);
    accepted=false; lambda=1;
    for backtrack=1:40
        trial=u+lambda*direction;
        ht=h(trial);
        trialMerit=0.5*dot(trial,trial)+penalty*abs(ht);
        if isfinite(trialMerit) && trialMerit<=merit+1e-4*lambda*slope
            accepted=true; break;
        end
        lambda=lambda/2;
    end
    if ~accepted, reason='line search failed'; break; end
    u=trial;
end
sol=struct('u',u,'converged',converged,'iterations',it,'reason',reason, ...
    'history',hist(1:it+1,:));
end
