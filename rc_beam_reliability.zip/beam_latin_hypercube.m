% CE653 - RC beam reliability, current agreed 6 m design.
% Standalone SCRIPT: press Run or type its filename (without .m).
% MATLAB R2016b or later; NO Statistics or Optimization Toolbox required.
% Local functions appear at the end. Run the complete script, not a selection.
% Each file contains its own identical input/model functions for portability.
% Edit beam_parameters() below to change inputs; keep all four copies aligned.
% Assumption: independent basic variables, common diameter for all 3 bars.
% No load factors 1.5 or material factor 0.87 in the probabilistic g function.
clear; clc;
p=beam_parameters();
show_parameters(p);

%% Independently randomized Latin hypercube replicates
% Every marginal has one point in each of nPerRep probability strata.
% Replicates are independent; points WITHIN a replicate are NOT independent.
% Therefore uncertainty is estimated BETWEEN replicate Pf estimates, NOT
% using a binomial formula on all the dependent LHS points.
rng(1653,'twister');
nPerRep=1000000;
nRep=20;
assert(nRep>=10 && nRep==floor(nRep),'Use at least 10 independent replicates.');
assert(nPerRep>=2 && nPerRep==floor(nPerRep));
pfRep=zeros(nRep,1); failures=zeros(nRep,1); history=zeros(nRep,4);
nonYield=0; invalid=0; negativeQ=0; failNonYield=0;
meanG=0; M2=0; nDone=0; timer=tic;
fprintf('\nLHS: %d independent replicates of %d samples\n',nRep,nPerRep);
for r=1:nRep
    P=zeros(nPerRep,numel(p.mu));
    for j=1:numel(p.mu)
        permutation=randperm(nPerRep).';
        P(:,j)=(permutation-1+rand(nPerRep,1))/nPerRep;
    end
    X=from_uniform(P,p); clear P;
    [g,~,~,dg]=beam_limit_state(X,p); clear X;
    assert(all(isfinite(g)),'Nonfinite g encountered. Review the input model.');
    failures(r)=sum(g<=0); pfRep(r)=failures(r)/nPerRep;
    nonYield=nonYield+sum(dg.nonYield); invalid=invalid+sum(dg.invalid);
    negativeQ=negativeQ+sum(dg.negativeQ);
    failNonYield=failNonYield+sum((g<=0)&dg.nonYield);
    batchMean=mean(g); delta=batchMean-meanG; nNew=nDone+nPerRep;
    M2=M2+sum((g-batchMean).^2)+delta^2*nDone*nPerRep/nNew;
    meanG=meanG+delta*nPerRep/nNew; nDone=nNew;
    pfRunning=mean(pfRep(1:r));
    history(r,:)=[r,nDone,pfRunning,beta_from_pf(pfRunning)];
    fprintf('Rep=%2d failures=%4d pooled Pf=%.6g beta=%.5f\n', ...
        r,failures(r),pfRunning,beta_from_pf(pfRunning));
end
Pf=mean(pfRep); beta=beta_from_pf(Pf); % transform pooled Pf; do not average betas
se=std(pfRep,0)/sqrt(nRep); covEstimator=NaN;
if Pf>0, covEstimator=se/Pf; end
% Approximate Student-t interval based on independent replicate estimates.
df=nRep-1; q=betaincinv(0.05,df/2,0.5);
tcrit=sqrt(df*(1/q-1));
pfCI=[max(0,Pf-tcrit*se),min(1,Pf+tcrit*se)];
if se==0
    % Identical counts, especially all zero, cannot justify a zero-width CI.
    pfCI=[NaN,NaN];
end
betaCI=[beta_from_pf(pfCI(2)),beta_from_pf(pfCI(1))];
results=struct('method','Replicated randomized LHS','parameters',p, ...
    'n_per_replicate',nPerRep,'n_replicates',nRep,'N',nDone, ...
    'failures_per_replicate',failures,'Pf_per_replicate',pfRep, ...
    'Pf',Pf,'beta',beta,'SE_Pf',se,'COV_Pf_estimator',covEstimator, ...
    'Pf_CI95_approx',pfCI,'beta_CI95_approx',betaCI,'history',history, ...
    'sample_mean_g',meanG,'sample_sd_g',sqrt(M2/(nDone-1)), ...
    'non_yield_samples',nonYield,'invalid_samples',invalid, ...
    'failure_and_non_yield_samples',failNonYield,'elapsed_seconds',toc(timer));
fprintf('\nLATIN HYPERCUBE RESULTS\n');
fprintf('Pf = %.8g; beta = %.8f\n',Pf,beta);
fprintf('Replicate-based approximate 95%% CI(Pf): [%.8g, %.8g]\n',pfCI);
fprintf('Transformed approximate 95%% CI(beta): [%.6f, %.6f]\n',betaCI);
fprintf('Estimated sampling COV(Pf) = %.2f%%\n',100*covEstimator);
fprintf('Sample mean(g)=%.6f; SD(g)=%.6f kN m\n',meanG,results.sample_sd_g);
fprintf('Failures outside steel-yield domain: %d\n',failNonYield);
if Pf==0 || se==0
    fprintf('Insufficient replication variability: no informative CI reported. Increase sample size.\n');
end
if sum(failures)<100 || sum(failures>0)<10
    fprintf('Rare-failure estimates remain noisy; increase nPerRep and/or nRep.\n');
end
show_diagnostic(nonYield,invalid,negativeQ,nDone);
fprintf('Elapsed: %.1f s. Output structure: results. No files written.\n',results.elapsed_seconds);

%% Local functions

function p = beam_parameters()
% Variable order is identical in all four standalone scripts.
% All 11 basic variables are assumed INDEPENDENT. Derived variables are not.
% References and transfer assumptions are documented in README.md.
p.names = {'C','F','b','D','c','phi_l','phi_st','gamma_RC','G','Q','theta_R'};
p.units = {'MPa','MPa','mm','mm','mm','mm','mm','kN/m^3','kN/m','kN/m','-'};
p.L = 6;                         % fixed effective span, m
p.nBars = 3;                     % three bars sharing one random diameter
p.Es = 200000; p.epscu = 0.0035; % only for yield-assumption diagnostic
% M25: 25 MPa is assumed to be the 5th percentile; COV = 0.15.
p.logSD_C = sqrt(log(1+0.15^2));
p.logMean_C = log(25)+1.6448536269514722*p.logSD_C;
muC = exp(p.logMean_C+0.5*p.logSD_C^2);
muQ = 10/(1+0.35*0.25);          % Correia et al. nominal-to-mean relation
p.mu = [muC,560,250.75,451.35,30,20,8,25,5.25,muQ,1.01];
p.sd = [0.15*muC,30,5.50,6.70,3,0.20,0.08,1.25,0.525,0.25*muQ,0.0465];
p.type = {'Lognormal','Normal','Normal','Normal','Normal','Normal', ...
          'Normal','Normal','Normal','Gumbel-max','Normal'};
p.gumbelScale = p.sd(10)*sqrt(6)/pi;
p.gumbelLocation = p.mu(10)-0.5772156649015329*p.gumbelScale;
end

function [g,R,S,diag] = beam_limit_state(X,p)
% Rows = samples; columns use p.names. Strengths MPa, lengths mm except L(m).
% EXACT agreed Ranganathan flexural model, WITHOUT partial safety factors.
C=X(:,1); F=X(:,2); b=X(:,3); D=X(:,4); c=X(:,5);
phiL=X(:,6); phiSt=X(:,7); gamma=X(:,8); G=X(:,9); Q=X(:,10); B=X(:,11);
As=p.nBars*pi*phiL.^2/4;
d=D-c-phiSt-phiL/2;
wSelf=gamma.*b.*D*1e-6;  % effective RC weight already includes steel
R=1e-6*B.*F.*As.*(d-0.77*F.*As./(b.*C));
S=(G+Q+wSelf)*p.L^2/8;
g=R-S;                 % kN m; failure g <= 0
if nargout>3
    % Do NOT reject, truncate or alter samples: doing so changes the model.
    diag.invalid = any(~isfinite(X),2) | any(X(:,[1:9,11])<=0,2) | d<=0;
    diag.negativeQ = Q<0; % tiny formal negative tail of Gumbel distribution
    % Diagnostic only: steel-yield resistance requires strain compatibility.
    xu=F.*As./(0.546*C.*b);
    diag.yieldLimit = p.epscu./(p.epscu+F/p.Es);
    diag.xuOverD = xu./d;
    diag.nonYield = diag.xuOverD > diag.yieldLimit;
    diag.As=As; diag.d=d; diag.wSelf=wSelf;
end
end

function X = from_uniform(P,p)
% Independent inverse-CDF transform, including Gumbel for MAXIMA.
P=min(max(P,realmin),1-eps);
Z=-sqrt(2)*erfcinv(2*P);
X=bsxfun(@plus,p.mu,bsxfun(@times,Z,p.sd));
X(:,1)=exp(p.logMean_C+p.logSD_C*Z(:,1));
X(:,10)=p.gumbelLocation-p.gumbelScale*log(-log(P(:,10)));
end

function X = from_standard_normal(U,p)
X=bsxfun(@plus,p.mu,bsxfun(@times,U,p.sd));
X(:,1)=exp(p.logMean_C+p.logSD_C*U(:,1));
% Phi(U), numerically protected at machine precision only.
P=min(max(0.5*erfc(-U(:,10)/sqrt(2)),realmin),1-eps);
X(:,10)=p.gumbelLocation-p.gumbelScale*log(-log(P));
end

function grad = central_gradient(fun,x,step)
% Returns a row gradient. Check two step sizes in the deterministic methods.
grad=zeros(size(x));
for j=1:numel(x)
    xp=x; xm=x; xp(j)=xp(j)+step(j); xm(j)=xm(j)-step(j);
    grad(j)=(fun(xp)-fun(xm))/(2*step(j));
end
end

function b = beta_from_pf(pf)
% beta = -Phi^{-1}(Pf); returns +Inf for Pf=0 and -Inf for Pf=1.
b=sqrt(2)*erfcinv(2*pf);
end

function show_parameters(p)
fprintf('\nIndependent basic variables (arithmetic mean and SD):\n');
fprintf('%-11s %-13s %12s %12s %-8s\n','Variable','Distribution','Mean','SD','Unit');
for j=1:numel(p.mu)
    fprintf('%-11s %-13s %12.6g %12.6g %-8s\n',p.names{j},p.type{j},p.mu(j),p.sd(j),p.units{j});
end
fprintf('Span = %.3f m; number of tension bars = %d.\n',p.L,p.nBars);
fprintf('Model: Ranganathan yielded-steel flexure, independent inputs.\n');
end

function show_diagnostic(nonYield,invalid,negativeQ,N)
if invalid>0
    warning('Beam:InvalidSamples', ...
      '%d / %d samples have invalid geometry or nonpositive physical inputs. Results include them; review model.',invalid,N);
end
if negativeQ>0
    warning('Beam:NegativeLiveLoad','%d negative Gumbel live-load samples retained.',negativeQ);
end
if nonYield>0
    warning('Beam:YieldAssumption', ...
      ['%d / %d samples (%.5g%%) exceed the steel-yield strain limit. ', ...
       'The agreed equation was retained; results refer to this equation, not a multi-mode capacity model.'], ...
      nonYield,N,100*nonYield/N);
end
end
