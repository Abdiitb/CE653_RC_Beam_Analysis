% CE653 - RC beam reliability, current agreed 6 m design.
% Standalone SCRIPT: press Run or type its filename (without .m).
% MATLAB R2016b or later; NO Statistics or Optimization Toolbox required.
% Local functions appear at the end. Run the complete script, not a selection.
% Each file contains its own identical input/model functions for portability.
% Edit beam_parameters() below to change inputs; keep all four copies aligned.
% Assumption: independent basic variables, common diameter for all 3 bars.
% No load factors 1.5 or material factor 0.87 in the probabilistic g function.
clear; clc;
p=beam_parameters();
show_parameters(p);

%% Crude Monte Carlo simulation: fixed sample size, reproducible seed
% Pf is small (~a few per million), so 20 million is intentional.
% N=1e5 or 1e6 is useful only as a smoke test, not a reliable tail estimate.
rng(653,'twister');
N=20000000;
batchSize=100000;
assert(N>=1 && N==floor(N) && batchSize>=1);
nFail=0; nDone=0; nonYield=0; invalid=0; negativeQ=0; failNonYield=0;
meanG=0; M2=0; history=zeros(ceil(N/batchSize),4); timer=tic;
fprintf('\nMONTE CARLO: N = %d, batch size = %d\n',N,batchSize);
for k=1:ceil(N/batchSize)
    nb=min(batchSize,N-nDone);
    X=from_uniform(rand(nb,numel(p.mu)),p);
    [g,~,~,dg]=beam_limit_state(X,p);
    assert(all(isfinite(g)),'Nonfinite g encountered. Review the input model.');
    nFail=nFail+sum(g<=0);
    nonYield=nonYield+sum(dg.nonYield); invalid=invalid+sum(dg.invalid);
    negativeQ=negativeQ+sum(dg.negativeQ);
    failNonYield=failNonYield+sum((g<=0)&dg.nonYield);
    % Stable pooled sample moments, independent of memory batch size.
    batchMean=mean(g); delta=batchMean-meanG; nNew=nDone+nb;
    M2=M2+sum((g-batchMean).^2)+delta^2*nDone*nb/nNew;
    meanG=meanG+delta*nb/nNew; nDone=nNew;
    phat=nFail/nDone;
    history(k,:)=[nDone,nFail,phat,beta_from_pf(phat)];
    if mod(k,20)==0 || nDone==N
        fprintf('N=%9d failures=%5d Pf=%.6g beta=%.5f\n',nDone,nFail,phat,beta_from_pf(phat));
    end
end
Pf=nFail/N; beta=beta_from_pf(Pf);
% Exact binomial Clopper-Pearson interval; only valid for independent MC.
[pfLow,pfHigh]=binomial_interval(nFail,N,0.05);
betaCI=[beta_from_pf(pfHigh),beta_from_pf(pfLow)];
se=sqrt(Pf*(1-Pf)/N); covEstimator=NaN;
if Pf>0, covEstimator=se/Pf; end
results=struct('method','Crude Monte Carlo','parameters',p,'N',N, ...
    'failures',nFail,'Pf',Pf,'beta',beta,'Pf_CI95',[pfLow,pfHigh], ...
    'beta_CI95',betaCI,'SE_Pf',se,'COV_Pf_estimator',covEstimator, ...
    'sample_mean_g',meanG,'sample_sd_g',sqrt(M2/max(N-1,1)), ...
    'history',history,'non_yield_samples',nonYield,'invalid_samples',invalid, ...
    'failure_and_non_yield_samples',failNonYield,'elapsed_seconds',toc(timer));
fprintf('\nMONTE CARLO RESULTS\n');
fprintf('Pf = %.8g; beta = %.8f\n',Pf,beta);
fprintf('Exact binomial 95%% CI(Pf): [%.8g, %.8g]\n',pfLow,pfHigh);
fprintf('Transformed 95%% CI(beta): [%.6f, %.6f]\n',betaCI);
fprintf('Estimated sampling COV(Pf) = %.2f%%\n',100*covEstimator);
fprintf('Sample mean(g)=%.6f; SD(g)=%.6f kN m\n',meanG,results.sample_sd_g);
fprintf('Failures outside steel-yield domain: %d\n',failNonYield);
if nFail==0
    upperOneSided=1-0.05^(1/N);
    fprintf('ZERO failures: infinite point beta does NOT prove safety.\n');
    fprintf('One-sided 95%% upper Pf = %.8g; corresponding beta lower bound = %.5f\n', ...
        upperOneSided,beta_from_pf(upperOneSided));
end
if nFail<100
    fprintf('Few failures: increase N for a more precise beta/Pf estimate (100 failures ~10%% COV).\n');
end
show_diagnostic(nonYield,invalid,negativeQ,N);
fprintf('Elapsed: %.1f s. Output structure: results. No files written.\n',results.elapsed_seconds);

%% Local functions

function p = beam_parameters()
% Variable order is identical in all four standalone scripts.
% All 11 basic variables are assumed INDEPENDENT. Derived variables are not.
% References and transfer assumptions are documented in README.md.
p.names = {'C','F','b','D','c','phi_l','phi_st','gamma_RC','G','Q','theta_R'};
p.units = {'MPa','MPa','mm','mm','mm','mm','mm','kN/m^3','kN/m','kN/m','-'};
p.L = 6;                         % fixed effective span, m
p.nBars = 3;                     % three bars sharing one random diameter
p.Es = 200000; p.epscu = 0.0035; % only for yield-assumption diagnostic
% M25: 25 MPa is assumed to be the 5th percentile; COV = 0.15.
p.logSD_C = sqrt(log(1+0.15^2));
p.logMean_C = log(25)+1.6448536269514722*p.logSD_C;
muC = exp(p.logMean_C+0.5*p.logSD_C^2);
muQ = 10/(1+0.35*0.25);          % Correia et al. nominal-to-mean relation
p.mu = [muC,560,250.75,451.35,30,20,8,25,5.25,muQ,1.01];
p.sd = [0.15*muC,30,5.50,6.70,3,0.20,0.08,1.25,0.525,0.25*muQ,0.0465];
p.type = {'Lognormal','Normal','Normal','Normal','Normal','Normal', ...
          'Normal','Normal','Normal','Gumbel-max','Normal'};
p.gumbelScale = p.sd(10)*sqrt(6)/pi;
p.gumbelLocation = p.mu(10)-0.5772156649015329*p.gumbelScale;
end

function [g,R,S,diag] = beam_limit_state(X,p)
% Rows = samples; columns use p.names. Strengths MPa, lengths mm except L(m).
% EXACT agreed Ranganathan flexural model, WITHOUT partial safety factors.
C=X(:,1); F=X(:,2); b=X(:,3); D=X(:,4); c=X(:,5);
phiL=X(:,6); phiSt=X(:,7); gamma=X(:,8); G=X(:,9); Q=X(:,10); B=X(:,11);
As=p.nBars*pi*phiL.^2/4;
d=D-c-phiSt-phiL/2;
wSelf=gamma.*b.*D*1e-6;  % effective RC weight already includes steel
R=1e-6*B.*F.*As.*(d-0.77*F.*As./(b.*C));
S=(G+Q+wSelf)*p.L^2/8;
g=R-S;                 % kN m; failure g <= 0
if nargout>3
    % Do NOT reject, truncate or alter samples: doing so changes the model.
    diag.invalid = any(~isfinite(X),2) | any(X(:,[1:9,11])<=0,2) | d<=0;
    diag.negativeQ = Q<0; % tiny formal negative tail of Gumbel distribution
    % Diagnostic only: steel-yield resistance requires strain compatibility.
    xu=F.*As./(0.546*C.*b);
    diag.yieldLimit = p.epscu./(p.epscu+F/p.Es);
    diag.xuOverD = xu./d;
    diag.nonYield = diag.xuOverD > diag.yieldLimit;
    diag.As=As; diag.d=d; diag.wSelf=wSelf;
end
end

function X = from_uniform(P,p)
% Independent inverse-CDF transform, including Gumbel for MAXIMA.
P=min(max(P,realmin),1-eps);
Z=-sqrt(2)*erfcinv(2*P);
X=bsxfun(@plus,p.mu,bsxfun(@times,Z,p.sd));
X(:,1)=exp(p.logMean_C+p.logSD_C*Z(:,1));
X(:,10)=p.gumbelLocation-p.gumbelScale*log(-log(P(:,10)));
end

function X = from_standard_normal(U,p)
X=bsxfun(@plus,p.mu,bsxfun(@times,U,p.sd));
X(:,1)=exp(p.logMean_C+p.logSD_C*U(:,1));
% Phi(U), numerically protected at machine precision only.
P=min(max(0.5*erfc(-U(:,10)/sqrt(2)),realmin),1-eps);
X(:,10)=p.gumbelLocation-p.gumbelScale*log(-log(P));
end

function grad = central_gradient(fun,x,step)
% Returns a row gradient. Check two step sizes in the deterministic methods.
grad=zeros(size(x));
for j=1:numel(x)
    xp=x; xm=x; xp(j)=xp(j)+step(j); xm(j)=xm(j)-step(j);
    grad(j)=(fun(xp)-fun(xm))/(2*step(j));
end
end

function b = beta_from_pf(pf)
% beta = -Phi^{-1}(Pf); returns +Inf for Pf=0 and -Inf for Pf=1.
b=sqrt(2)*erfcinv(2*pf);
end

function show_parameters(p)
fprintf('\nIndependent basic variables (arithmetic mean and SD):\n');
fprintf('%-11s %-13s %12s %12s %-8s\n','Variable','Distribution','Mean','SD','Unit');
for j=1:numel(p.mu)
    fprintf('%-11s %-13s %12.6g %12.6g %-8s\n',p.names{j},p.type{j},p.mu(j),p.sd(j),p.units{j});
end
fprintf('Span = %.3f m; number of tension bars = %d.\n',p.L,p.nBars);
fprintf('Model: Ranganathan yielded-steel flexure, independent inputs.\n');
end

function show_diagnostic(nonYield,invalid,negativeQ,N)
if invalid>0
    warning('Beam:InvalidSamples', ...
      '%d / %d samples have invalid geometry or nonpositive physical inputs. Results include them; review model.',invalid,N);
end
if negativeQ>0
    warning('Beam:NegativeLiveLoad','%d negative Gumbel live-load samples retained.',negativeQ);
end
if nonYield>0
    warning('Beam:YieldAssumption', ...
      ['%d / %d samples (%.5g%%) exceed the steel-yield strain limit. ', ...
       'The agreed equation was retained; results refer to this equation, not a multi-mode capacity model.'], ...
      nonYield,N,100*nonYield/N);
end
end

function [lo,hi]=binomial_interval(k,n,a)
if k==0, lo=0; else, lo=betaincinv(a/2,k,n-k+1); end
if k==n, hi=1; else, hi=betaincinv(1-a/2,k+1,n-k); end
end
